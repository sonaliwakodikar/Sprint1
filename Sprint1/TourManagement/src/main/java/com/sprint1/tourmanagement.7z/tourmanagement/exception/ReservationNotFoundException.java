package com.sprint1.tourmanagement.exception;

public class ReservationNotFoundException extends RuntimeException{
	public ReservationNotFoundException(String msg) {
		super(msg);
	}

}
