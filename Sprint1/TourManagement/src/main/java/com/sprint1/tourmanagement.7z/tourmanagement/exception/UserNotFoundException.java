package com.sprint1.tourmanagement.exception;

public class UserNotFoundException extends RuntimeException{
	
	public UserNotFoundException(String msg) {
		super(msg);
		
	}

}
