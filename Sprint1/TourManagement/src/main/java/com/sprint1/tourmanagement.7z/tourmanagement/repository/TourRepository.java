package com.sprint1.tourmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sprint1.tourmanagement.entity.Tour;

public interface TourRepository extends JpaRepository<Tour,Integer>{

}
